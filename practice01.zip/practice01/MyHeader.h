#pragma once
#include <stdio.h>

void Hello()
{
	printf("Hello World!\n");
}

int abs(int x)
{
	return (x < 0) ? -x : x;
}